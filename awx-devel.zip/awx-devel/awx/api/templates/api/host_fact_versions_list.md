# List Fact Scans for a Host by Module and Date

Make a GET request to this resource to retrieve system tracking scans by module and date/time

You may filter scan runs using the `from` and `to` properties:

`?from=2015-06-01%2012:00:00&to=2015-06-03`

You may also filter by module

`?module=packages`
