{% extends "api/sub_list_create_api_view.md" %}

{% block post_create %}
{% include "api/_schedule_list_common.md" %}
{% endblock %}
