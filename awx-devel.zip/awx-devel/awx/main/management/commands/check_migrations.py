from django.core.management.commands.makemigrations import Command as MakeMigrations


class Command(MakeMigrations):
    pass
